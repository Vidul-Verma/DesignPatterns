/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gof_strategy_grader;

/**
 *
 * @author Dr Hoffman
 */
public class GradeAllCs implements Strategy {
     public void GradeCourse(int[] ids, char[] grades){
           for(int i=0; i< ids.length; i++)
             grades[i] = 'C';
     }
}
