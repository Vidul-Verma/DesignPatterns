/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gof_strategy_grader;


public class appClass {
    Course  cecs277;
    int[] ID = {1234,2345,3456,4567,5678,6789,7890};
    public void go(){
        cecs277 = new Course(ID);
        
        cecs277.GradeCourse();
        cecs277.PrintGradeList();
        
    }
}
