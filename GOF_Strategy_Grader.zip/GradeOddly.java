/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gof_strategy_grader;

/**
 *
 * @author Dr Hoffman
 */
public class GradeOddly implements Strategy {
      public void GradeCourse(int[] StuID, char[] grades){
         for(int i=0; i< StuID.length; i++)
            if(StuID[i] % 2 == 1)
		grades[i] = 'A';
            else grades[i] = 'B';
      }
}
