/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gof_strategy_grader;

import java.util.Scanner;

public class Course {
    Strategy    strategy;
    int[] ids;
    char[] grades;
    public Course(int[] IDs){
        ids = IDs;
        grades = new char[ids.length];
    }
    Strategy MoodFactory(int mood) {
	if(mood == 1)
		return new GradeAllAs();
	if(mood == 2)
		return new GradeOddly();
	if(mood == 3) 
		return new GradeRandomly();
	if(mood ==4)
		return  new GradeAllCs();
//	return new GradeAlternately();
        return null;
}
    public void GradeCourse(){
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Dr. Hoffman, how did you like this class?\n");
        System.out.println("1 = Loved them\n2 = Liked them\n3 = Okay\n4 = Not much\n");
        System.out.print("Mood = ");
        int mood = sc.nextInt();
        strategy = MoodFactory(mood);
        strategy.GradeCourse(ids, grades);
    }
    public void PrintGradeList(){
        for(int i=0; i< ids.length; i++)
            System.out.printf("%d  %c\n", ids[i], grades[i]);
    }
}

