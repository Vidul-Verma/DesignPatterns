/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gof_strategy_grader;

/**
 *
 * @author Dr Hoffman
 */
public class GOF_Strategy_Grader {

    /**
     * @param args the command line arguments
     */
    static appClass app;
    public static void main(String[] args) {
        app = new appClass();
        app.go();
    }
    
}
