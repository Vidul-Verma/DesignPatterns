
public interface Iterator {
	Object First();
	Object Current();
	boolean isDone();
	boolean Next();
}
