
public interface CustomArray {
	
	Iterator getIterator();
}
