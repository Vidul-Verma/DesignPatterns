/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gof_command_calc;

/**
 *
 * @author Daddy
 */
public abstract class Command {
    public abstract void Execute();
    public abstract void UnExecute();
}
