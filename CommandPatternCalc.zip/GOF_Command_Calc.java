/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gof_command_calc;

/**
 *
 * @author Daddy
 */
public class GOF_Command_Calc {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Invoker user = new Invoker();

 

      // User presses calculator buttons

      user.Compute('+', 100);

      user.Compute('-', 50);

      user.Compute('*', 10);

      user.Compute('/', 2);

 

      // Undo 4 commands

      user.Undo(4);

 

      // Redo 3 commands

      user.Redo(3);
    }
    
}
