
public interface Subscribers {

	public void updateDisplay(String[] apRanks, String pollName);
}
