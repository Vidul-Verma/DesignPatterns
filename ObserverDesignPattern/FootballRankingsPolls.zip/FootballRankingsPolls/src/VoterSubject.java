
public interface VoterSubject {

	public void registerPoll(PollSubjectAndObsever sb);
	public void votePolls();
	
}
