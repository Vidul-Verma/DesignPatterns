/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gof_cor_coins;

/**
 *
 * @author Daddy
 */
public class GOF_COR_Coins {

    static AppClass app;
    public static void main(String[] args) {
        app = new AppClass();
        app.run();
    }
    
}
