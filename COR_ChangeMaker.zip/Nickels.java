/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gof_cor_coins;

public class Nickels extends Handler {

    @Override
    public void HandleRequest(Money m) {
        if (m.balance	>= 5)
        {
           m.Nickels = m.balance / 5;
           m.balance = m.balance % 5;
        }
        else 
            if (successor != null)
            {
                successor.HandleRequest(m);
            }
    }
}
