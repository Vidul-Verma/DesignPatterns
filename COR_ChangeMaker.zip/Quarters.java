/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gof_cor_coins;

/**
 *
 * @author Daddy
 */
public class Quarters extends Handler {

	@Override
	public void HandleRequest(Money m) {
		// TODO Auto-generated method stub
		 if (m.balance	>= 25)
	      {
			m.Quarters = m.balance / 25;
			m.balance = m.balance % 25;
		  }
	      else if (successor != null)
	      {
	        successor.HandleRequest(m);
	      }
	}
}
