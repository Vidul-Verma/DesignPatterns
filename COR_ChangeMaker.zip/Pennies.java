/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package gof_cor_coins;


public class Pennies extends Handler {
    @Override
    public void HandleRequest(Money m) {
        // TODO Auto-generated method stub
        m.Pennies = m.balance;
        m.balance = 0;
    }
}
