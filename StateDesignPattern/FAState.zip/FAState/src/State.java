
public interface State {
	void inputA();
	void inputB();
	String getStateName();
}
